import 'package:flutter/material.dart';

import '../services/levels.dart';
import '../services/placement.dart';
import '../study_controller.dart';
import '../theme.dart';
import '../widgets/level_shield.dart';
import '../widgets/pill_button.dart';

enum _Stage { welcome, test, result, picker }

/// Úvodní výběr úrovně: začít od nuly, vybrat úroveň, nebo udělat krátký test.
/// Při prvním otevření kurzu se ukáže sama, později je v Nastavení.
class PlacementPage extends StatefulWidget {
  final StudyController controller;
  final bool firstRun;

  const PlacementPage({
    super.key,
    required this.controller,
    required this.firstRun,
  });

  @override
  State<PlacementPage> createState() => _PlacementPageState();
}

class _PlacementPageState extends State<PlacementPage> {
  _Stage _stage = _Stage.welcome;
  PlacementTest? _test;

  StudyController get c => widget.controller;

  void _startTest() {
    final t = PlacementTest(total: c.totalWords);
    setState(() {
      _test = t;
      _stage = t.done ? _Stage.result : _Stage.test;
    });
  }

  void _answer(bool known) {
    final t = _test!;
    t.answer(known);
    setState(() {
      if (t.done) _stage = _Stage.result;
    });
  }

  Future<void> _apply(int known) async {
    // Dřívější výběr se přepíše; procvičená slova zůstanou, proto jen informace.
    final n = c.placementCardCount;
    if (n > 0) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Upravit úroveň?'),
          content: Text(
            'Přepíšu $n slov z předchozího výběru. Slova, která jsi sama '
            'procvičila, zůstanou beze změny.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Zrušit'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Pokračovat'),
            ),
          ],
        ),
      );
      if (ok != true || !mounted) return;
    }
    c.applyPlacement(known: known, answers: _test?.answers ?? const []);
    if (mounted) Navigator.of(context).pop();
  }

  void _fromScratch() {
    if (widget.firstRun) c.skipPlacement();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _stage == _Stage.welcome,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) {
          if (widget.firstRun) c.skipPlacement(); // zavření = od nuly
        } else {
          setState(() => _stage = _Stage.welcome);
        }
      },
      child: Scaffold(
        backgroundColor: kBg,
        body: SafeArea(
          child: Column(
            children: [
              _topBar(),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 0, 22, 20),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: KeyedSubtree(key: ValueKey(_stage), child: _body()),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Šipka zpět: z dalších kroků vrací na úvod, z úvodu zavře stránku.
  /// Při prvním spuštění (není kam se vrátit) se na úvodu nezobrazuje.
  Widget _topBar() {
    final show = _stage != _Stage.welcome || !widget.firstRun;
    return SizedBox(
      height: 52,
      child: Align(
        alignment: Alignment.centerLeft,
        child: show
            ? Padding(
                padding: const EdgeInsets.only(left: 8),
                child: IconButton(
                  tooltip: 'Zpět',
                  onPressed: () => Navigator.of(context).maybePop(),
                  icon: const Icon(Icons.arrow_back_rounded, color: kInk),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white,
                    fixedSize: const Size(44, 44),
                    shadowColor: Colors.black,
                    elevation: 1,
                  ),
                ),
              )
            : null,
      ),
    );
  }

  Widget _body() {
    switch (_stage) {
      case _Stage.welcome:
        return _welcome();
      case _Stage.test:
        return _testView();
      case _Stage.result:
        return _result();
      case _Stage.picker:
        return _picker();
    }
  }

  // ---------------------------------------------------------------- úvod
  Widget _welcome() {
    return ListView(
      children: [
        const SizedBox(height: 4),
        const Text(
          'Odkud začneš?',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: kInk),
        ),
        const SizedBox(height: 8),
        const Text(
          'Když už část slov umíš, nemusíš je učit od začátku. Slova, která '
          'označíme jako známá, se ti budou připomínat jen postupně.',
          style: TextStyle(fontSize: 15, color: kMuted, height: 1.35),
        ),
        const SizedBox(height: 22),
        if (c.totalWords >= 60)
          _OptionCard(
            icon: Icons.bolt_rounded,
            title: 'Udělat krátký test',
            subtitle: 'Asi 20 slov, zhruba dvě minuty. Ukáže doporučenou úroveň.',
            highlighted: true,
            onTap: _startTest,
          ),
        if (c.levels.isNotEmpty)
          _OptionCard(
            icon: Icons.stairs_rounded,
            title: 'Vybrat úroveň sám',
            subtitle: 'Řeknu, kolik slov už umím.',
            onTap: () => setState(() => _stage = _Stage.picker),
          ),
        _OptionCard(
          icon: Icons.flag_rounded,
          title: 'Začít od nuly',
          subtitle: 'Žádná slova zatím neznám.',
          onTap: _fromScratch,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------- test
  Widget _testView() {
    final t = _test!;
    final rank = t.currentRank!;
    final key = c.order[rank];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const Text(
              'Krátký test',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: kMuted,
              ),
            ),
            const Spacer(),
            Text(
              'Slovo ${t.answers.length + 1}',
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: kBlue,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: t.progress),
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          builder: (_, v, _) => ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: v,
              minHeight: 10,
              backgroundColor: const Color(0xFFE3E7EE),
              color: kBlue,
            ),
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 40),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white, Color(0xFFF2F6FF)],
            ),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: kBlue.withValues(alpha: 0.10), width: 1.5),
            boxShadow: softShadow(0.10),
          ),
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: kBlue.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'Znáš význam tohoto slova?',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: kBlue,
                  ),
                ),
              ),
              const SizedBox(height: 38),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: ScaleTransition(
                    scale: Tween(begin: 0.94, end: 1.0).animate(anim),
                    child: child,
                  ),
                ),
                child: Text(
                  c.course.back(key),
                  key: ValueKey(rank),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                    color: kInk,
                    height: 1.15,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'Odpovídej upřímně. Slova, která nepoznáš, tě aplikace naučí.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12.5, color: kMuted),
        ),
        const Spacer(),
        Row(
          children: [
            Expanded(
              child: PillButton(
                label: 'Neznám',
                icon: Icons.close_rounded,
                filled: false,
                color: const Color(0xFFD64545),
                onPressed: () => _answer(false),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: PillButton(
                label: 'Znám',
                icon: Icons.check_rounded,
                color: kToneGreen.accent,
                onPressed: () => _answer(true),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ------------------------------------------------------------- výsledek
  Widget _result() {
    final est = _test!.estimate;
    final shown = (est / 50).round() * 50;
    final cur = Levels.current(c.levels, est);
    final next = Levels.next(c.levels, est);
    final atStart = est < 30;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Spacer(),
        if (cur != null && !atStart)
          Center(child: LevelShield(level: cur, earned: true, width: 84)),
        const SizedBox(height: 18),
        Text(
          atStart
              ? 'Začneš od začátku'
              : (cur != null ? 'Úroveň ${cur.code}' : 'Zatím před první úrovní'),
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: kInk,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          atStart
              ? 'Test vyšel tak, že žádná slova nebudu označovat jako známá.'
              : 'Odhad: znáš asi $shown nejčastějších slov.'
                  '${next != null ? ' Další úroveň ${next.code} je od ${next.threshold} slov.' : ''}',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 15, color: kMuted, height: 1.35),
        ),
        const Spacer(),
        PillButton(
          label: atStart ? 'Začít' : 'Potvrdit a začít',
          onPressed: () => _apply(est),
        ),
        const SizedBox(height: 10),
        if (c.levels.isNotEmpty)
          PillButton(
            label: 'Vybrat úroveň sám',
            filled: false,
            onPressed: () => setState(() => _stage = _Stage.picker),
          ),
        TextButton(
          onPressed: _startTest,
          child: const Text('Zopakovat test', style: TextStyle(color: kMuted)),
        ),
      ],
    );
  }

  // -------------------------------------------------------------- výběr
  Widget _picker() {
    return ListView(
      children: [
        const SizedBox(height: 4),
        const Text(
          'Kolik už umíš?',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: kInk),
        ),
        const SizedBox(height: 8),
        const Text(
          'Vyber nejvyšší úroveň, kterou už máš. Slova do ní se označí jako '
          'známá a budou se ti připomínat postupně.',
          style: TextStyle(fontSize: 15, color: kMuted, height: 1.35),
        ),
        const SizedBox(height: 20),
        _OptionCard(
          icon: Icons.flag_rounded,
          title: 'Začít od nuly',
          subtitle: 'Žádná slova neoznačím jako známá.',
          onTap: _fromScratch,
        ),
        for (final l in c.levels)
          _OptionCard(
            leading: LevelShield(level: l, earned: true, width: 32),
            title: 'Umím úroveň ${l.code}',
            subtitle: 'Prvních ${l.threshold} slov se označí jako známá.',
            onTap: () => _apply(l.threshold),
          ),
      ],
    );
  }
}

class _OptionCard extends StatelessWidget {
  final IconData? icon;
  final Widget? leading;
  final String title;
  final String subtitle;
  final bool highlighted;
  final VoidCallback onTap;

  const _OptionCard({
    this.icon,
    this.leading,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.highlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: softShadow(),
            border: Border.all(
              color: highlighted ? kBlue.withValues(alpha: 0.55) : const Color(0x00FFFFFF),
              width: 2,
            ),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 40,
                child: Center(
                  child: leading ??
                      Icon(icon, size: 30, color: highlighted ? kBlue : kInk),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: kInk,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(fontSize: 13.5, color: kMuted),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: kMuted),
            ],
          ),
        ),
      ),
    );
  }
}

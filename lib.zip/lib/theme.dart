import 'package:flutter/material.dart';

/// Dostupná témata vzhledu (volí se v nastavení).
enum AppThemeId {
  classic('Klasické'),
  autumn('Podzimní');

  final String label;
  const AppThemeId(this.label);
}

/// Měkký stín pro bílé karty.
List<BoxShadow> softShadow([double opacity = 0.07]) => [
  BoxShadow(
    color: Colors.black.withValues(alpha: opacity),
    blurRadius: 18,
    offset: const Offset(0, 6),
  ),
];

/// Barevný tón: měkký přechod výplně + sytá barva + barvy textu na výplni.
/// Význam: zelená = opakování, žlutá = učení, modrá/fialová = hlavní akce a nové.
class Tone {
  final Color a; // měkký přechod: levý horní roh
  final Color b; // měkký přechod: pravý dolní roh
  final Color accent; // sytá barva (čísla, ikony)
  final Color solidA; // sytý přechod (kruh, dlaždice)
  final Color solidB;
  final Color ink; // nadpis na výplni
  final Color inkSoft; // podtitulek na výplni
  final Color onSolid; // ikona na sytém kruhu

  const Tone({
    required this.a,
    required this.b,
    required this.accent,
    required this.solidA,
    required this.solidB,
    required this.ink,
    required this.inkSoft,
    required this.onSolid,
  });

  /// Měkký přechod výplně; [alpha] < 1 ho zesvětlí (pro menší prvky).
  LinearGradient soft([double alpha = 1]) => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [a.withValues(alpha: alpha), b.withValues(alpha: alpha)],
  );

  /// Sytý přechod (kruh s ikonou).
  LinearGradient get solid => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [solidA, solidB],
  );
}

/// Celá barevná paleta jednoho tématu.
class AppPalette {
  final Color bg; // pozadí obrazovek
  final Color blue; // hlavní barva (přepínače, posuvníky, akce)
  final Color ink; // hlavní text
  final Color muted; // doplňkový text
  final Tone toneBlue; // hlavní akce, nová slova
  final Tone toneGreen; // opakování
  final Tone toneAmber; // učení

  const AppPalette({
    required this.bg,
    required this.blue,
    required this.ink,
    required this.muted,
    required this.toneBlue,
    required this.toneGreen,
    required this.toneAmber,
  });
}

const AppPalette kClassicPalette = AppPalette(
  bg: Color(0xFFF4F6FA),
  blue: Color(kBlue),
  ink: Color(kInk),
  muted: Color(kMuted),
  toneBlue: Tone(
    a: Color(0xFFC4D8FF),
    b: Color.fromARGB(255, 230, 231, 251),
    //b: Color.fromARGB(255, 233, 228, 245),
    accent: Color(kBlue),
    solidA: Color(kBlue),
    solidB: Color.fromARGB(255, 106, 77, 235),
    ink: Color(0xFF1F2A6B),
    inkSoft: Color(0xFF3B4A99),
    onSolid: Color(0xFFE6EDFF),
  ),
  toneGreen: Tone(
    a: Color(0xFFBDEBD2),
    b: Color.fromARGB(255, 218, 244, 218),
    accent: Color(0xFF168A5B),
    solidA: Color(0xFF23C16B),
    solidB: Color(0xFF14A3A8),
    ink: Color(0xFF11513A),
    inkSoft: Color(0xFF1D6E52),
    onSolid: Color(0xFFE3F8EE),
  ),
  toneAmber: Tone(
    a: Color(0xFFFFE1A0),
    b: Color.fromARGB(255, 251, 241, 210),
    //b: Color(0xFFFFCBB4),
    accent: Color.fromARGB(255, 217, 140, 16),
    solidA: Color(0xFFFFB300),
    solidB: Color(0xFFFF7A45),
    ink: Color(0xFF6B3E08),
    inkSoft: Color(0xFF8F5410),
    onSolid: Color(0xFFFFF3DC),
  ),
);

/// Podzim: krémové pozadí, cihlová (hlavní), olivová (opakování), hořčicová (učení).
const AppPalette kAutumnPalette = AppPalette(
  bg: Color(0xFFFFF7EF),
  blue: Color(0xFFC4572D),
  ink: Color(0xFF3B2A20),
  muted: Color(0xFF7F6E62),
  toneBlue: Tone(
    a: Color(0xFFF6D2BE),
    b: Color(0xFFFBE6DA),
    accent: Color(0xFFB5472A),
    solidA: Color(0xFFC4572D),
    solidB: Color(0xFF9E3B2B),
    ink: Color(0xFF5A2412),
    inkSoft: Color(0xFF8A3B22),
    onSolid: Color(0xFFFFE9DD),
  ),
  toneGreen: Tone(
    a: Color(0xFFDCE6BD),
    b: Color(0xFFEDF2D5),
    accent: Color(0xFF5E7F2F),
    solidA: Color(0xFF6B8E3A),
    solidB: Color(0xFF3F7A4F),
    ink: Color(0xFF33441A),
    inkSoft: Color(0xFF4C6428),
    onSolid: Color(0xFFF0F6DC),
  ),
  toneAmber: Tone(
    a: Color(0xFFFFE29A),
    b: Color(0xFFFBF0CF),
    accent: Color(0xFFC98A0B),
    solidA: Color(0xFFE6A817),
    solidB: Color(0xFFD98A1B),
    ink: Color(0xFF5E3F05),
    inkSoft: Color(0xFF85580A),
    onSolid: Color(0xFFFFF3D6),
  ),
);

AppPalette paletteFor(AppThemeId id) =>
    id == AppThemeId.autumn ? kAutumnPalette : kClassicPalette;

/// Právě používaná paleta. Mění se při přepnutí tématu (main.dart).
AppPalette palette = kClassicPalette;

/// Původní názvy zůstávají, jen už nejsou `const`, ale čtou aktuální paletu.
Color get kBg => palette.bg;
Color get kBlue => palette.blue;
Color get kInk => palette.ink;
Color get kMuted => palette.muted;
Tone get kToneBlue => palette.toneBlue;
Tone get kToneGreen => palette.toneGreen;
Tone get kToneAmber => palette.toneAmber;

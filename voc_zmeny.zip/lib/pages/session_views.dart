import 'dart:math' as math;

import 'package:material_ui/material_ui.dart';

import '../services/study_session.dart';
import '../study_controller.dart';
import '../theme.dart';
import '../widgets/backup_actions.dart';
import '../widgets/card_status.dart';
import '../widgets/flash_card.dart';
import '../widgets/intro_card.dart';
import '../widgets/ipa_help_sheet.dart';
import '../widgets/learning_tips_sheet.dart';
import '../widgets/pill_button.dart';
import '../widgets/rounded_progress_bar.dart';
import '../widgets/swipe_hint.dart';
import '../widgets/tone_button.dart';
import '../widgets/backup_reminder.dart';

String _slov(int n) =>
    n == 1 ? 'slovo' : (n >= 2 && n <= 4 ? 'slova' : 'slov');

/// Obrazovka mezi fázemi (po opakování, po pětici, po dávce): shrnutí a volba, jak dál.
class InterludeView extends StatelessWidget {
  final StudyController c;
  const InterludeView({super.key, required this.c});

  @override
  Widget build(BuildContext context) {
    final s = c.session;
    late final IconData icon;
    late final List<Color> colors;
    late final String title;
    late String subtitle;
    final tiles = <_Tile>[];
    String? primaryLabel;
    VoidCallback? primary;

    switch (c.interlude!) {
      case InterludeKind.reviewsDone:
        icon = Icons.check_rounded;
        colors = [kToneGreen.solidA, kToneGreen.solidB];
        title = 'Opakování hotovo';
        tiles.add(_Tile(s.reviewedInBlock, 'zopakováno', kReviewColor));
        final more = s.backlog > 0;
        if (more) {
          subtitle = 'Zbývá ještě ${s.backlog} splatných slov.';
          tiles.add(_Tile(s.backlog, 'zbývá', kToneAmber.accent));
          primaryLabel = 'Pokračovat v opakování';
          primary = c.continueReviews;
        } else if (s.mode == StudyMode.both &&
            s.unseenCount + s.learningCount > 0) {
          final n = s.nextGroupCount;
          subtitle =
              s.goalReached
                  ? 'Dnešní cíl nových slov máš splněný. Chceš se učit dál?'
                  : 'Hotovo! Začít s novými slovy?';
          primaryLabel = 'Učit $n ${_slov(n)}';
          primary = c.startLearning;
        } else {
          subtitle = 'Dnes máš opakování hotové.';
        }
      case InterludeKind.groupDone:
        icon = Icons.auto_awesome_rounded;
        colors = [kToneAmber.a, kToneAmber.solidA];
        title = 'Skupina hotová';
        subtitle =
            s.goalReached
                ? 'Dnešní cíl nových slov máš splněný. Chceš se učit dál?'
                : 'Další skupina nových slov čeká.';
        tiles.add(_Tile(s.learnedInBlock, 'naučeno', kToneAmber.accent));
        if (s.skippedInBlock > 0) {
          tiles.add(_Tile(s.skippedInBlock, 'přeskočeno', kBlue));
        }
        primaryLabel = 'Učit ${s.nextGroupCount} ${_slov(s.nextGroupCount)}';
        primary = c.startLearning;
      case InterludeKind.blockDone:
        icon = Icons.emoji_events_rounded;
        colors = [kToneBlue.solidA, kToneBlue.solidB];
        title = 'Dnešní dávka hotová';
        subtitle = 'Chceš pokračovat dalším blokem?';
        tiles.add(_Tile(s.newInBlock, 'nových', kBlue));
        if (s.mode != StudyMode.learnOnly) {
          tiles.add(_Tile(s.reviewedInBlock, 'zopakováno', kReviewColor));
        }
        if (s.skippedInBlock > 0) {
          tiles.add(_Tile(s.skippedInBlock, 'přeskočeno', kToneAmber.accent));
        }
        primaryLabel = 'Pokračovat';
        primary = c.nextBlock;
      case InterludeKind.allDone:
        icon = Icons.celebration_rounded;
        colors = [kToneGreen.solidA, kToneGreen.solidB];
        title = 'Vše hotovo';
        subtitle = 'Teď není co opakovat ani se učit.';
    }

    final accuracy =
        s.answeredInBlock >= 5
            ? (s.correctInBlock * 100 / s.answeredInBlock).round()
            : null;
    final hardest = s.hardestInBlock;

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.6, end: 1.0),
                duration: const Duration(milliseconds: 550),
                curve: Curves.elasticOut,
                builder:
                    (context, v, child) =>
                        Transform.scale(scale: v, child: child),
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: colors,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: colors.last.withValues(alpha: 0.45),
                        blurRadius: 28,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Icon(icon, size: 62, color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 28),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                color: kInk,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: kMuted),
            ),
            if (tiles.isNotEmpty) ...[
              const SizedBox(height: 24),
              Row(
                children: [
                  for (var i = 0; i < tiles.length; i++) ...[
                    if (i > 0) const SizedBox(width: 10),
                    Expanded(child: tiles[i]),
                  ],
                ],
              ),
            ],
            if (accuracy != null || hardest != null) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kSurface,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: softShadow(0.05),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (accuracy != null)
                      Text(
                        'Přesnost: $accuracy % (${s.correctInBlock} z ${s.answeredInBlock})',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    if (accuracy != null && hardest != null)
                      const SizedBox(height: 6),
                    if (hardest != null)
                      Text(
                        'Nejvíc se pletlo: ${c.course.front(hardest)} – ${c.course.back(hardest)}',
                        style: TextStyle(fontSize: 14, color: kMuted),
                      ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 28),
            if (primary != null)
              PillButton(
                label: primaryLabel!,
                icon: Icons.arrow_forward_rounded,
                color: colors.last,
                onPressed: primary,
              ),
            const SizedBox(height: 8),
            if (c.canUndo)
              SizedBox(
                height: 46,
                child: TextButton.icon(
                  onPressed: c.undo,
                  icon: Icon(Icons.undo_rounded, size: 18, color: kMuted),
                  label: Text(
                    'Vrátit poslední kartu',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: kMuted,
                    ),
                  ),
                ),
              ),
            if (backupAvailable && c.interlude != InterludeKind.groupDone)
              BackupReminder(c: c),
            if (backupAvailable && c.interlude != InterludeKind.groupDone)
              SizedBox(
                height: 40,
                child: TextButton.icon(
                  onPressed: () => exportBackup(context, c),
                  icon: Icon(Icons.download_rounded, size: 18, color: kMuted),
                  label: Text(
                    'Stáhnout zálohu',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: kMuted,
                    ),
                  ),
                ),
              ),
            SizedBox(
              height: 46,
              child: TextButton(
                onPressed: c.finish,
                child: Text(
                  primary == null ? 'Zpět' : 'Skončit',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: kMuted,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final int value;
  final String label;
  final Color color;
  const _Tile(this.value, this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(18),
        boxShadow: softShadow(0.06),
      ),
      child: Column(
        children: [
          Text(
            '$value',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 13, color: kMuted)),
        ],
      ),
    );
  }
}

/// Rozměry tlačítek při představení nových slov (celý blok = výška + spodní odsazení).
const double kIntroButtonHeight = 48;
const double kIntroButtonsBottom = 24;

/// Procvičování: pruh postupu nahoře, karta uprostřed, tlačítka dole.
/// Spodní blok má stejnou výšku v učení i v opakování, takže karta sedí pořád na stejném místě.
class PracticeView extends StatefulWidget {
  final StudyController c;

  /// Otevře slovo v seznamu (ikonka úprav).
  final void Function(int key)? onOpenWord;
  const PracticeView({super.key, required this.c, this.onOpenWord});

  @override
  State<PracticeView> createState() => _PracticeViewState();
}

class _PracticeViewState extends State<PracticeView> {
  // posun vrchní karty, podle něj SwipeHint kreslí glow a nápis
  final ValueNotifier<double> _drag = ValueNotifier<double>(0);

  StudyController get c => widget.c;

  @override
  void initState() {
    super.initState();
    // Poprvé (i po aktualizaci) se žárovka s tipy sama otevře, ať je jasné,
    // co pod ní je.
    if (!c.settings.seenTipsHelp) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || c.settings.seenTipsHelp) return;
        c.markTipsHelpSeen();
        showLearningTips(context, c.course, firstTime: true);
      });
    }
  }

  void _exclude(int key) {
    c.excludeNew(key);
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: const Text('Slovo vyřazeno, už ho neuvidíš.'),
          action: SnackBarAction(
            label: 'Vrátit',
            onPressed: () => c.restoreWord(key),
          ),
        ),
      );
  }

  @override
  void dispose() {
    _drag.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final top = c.current;
    final nxt = c.next;
    final s = c.session;
    final reviewing = c.phase == Phase.reviewing;
    final firstTry = s.isFirstTry;
    final showButtons = c.isIntro || firstTry;
    final label =
        reviewing
            ? 'Opakování ${s.phaseDone} / ${s.phaseTotal}'
            : (c.isIntro
                ? 'Nová slova'
                : 'Učení ${s.phaseDone} / ${s.phaseTotal}');

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 14, 24, 0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    // Vlevo nápověda k fonetické abecedě, vpravo úpravy a Zpět.
                    SizedBox(
                      width: 80,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: 40,
                              height: 32,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                iconSize: 24,
                                color: kToneAmber.solidA,
                                tooltip: 'Tipy k učení',
                                onPressed:
                                    () => showLearningTips(context, c.course),
                                icon: const Icon(Icons.lightbulb_rounded),
                              ),
                            ),
                            if (hasIpaHelp(c.course))
                              SizedBox(
                                width: 40,
                                height: 32,
                                child: IconButton(
                                  padding: EdgeInsets.zero,
                                  iconSize: 22,
                                  color: kMuted,
                                  tooltip: 'Fonetická abeceda',
                                  onPressed:
                                      () => showIpaHelp(context, c.course),
                                  icon: const Icon(Icons.help_outline_rounded),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        label,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: kMuted,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 40,
                      height: 32,
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        iconSize: 22,
                        color: kMuted,
                        disabledColor: kFaint,
                        tooltip: 'Upravit slovo v seznamu',
                        onPressed:
                            top != null && widget.onOpenWord != null
                                ? () => widget.onOpenWord!(top)
                                : null,
                        icon: const Icon(Icons.edit_outlined),
                      ),
                    ),
                    SizedBox(
                      width: 40,
                      height: 38,
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        iconSize: 22,
                        color: kInk,
                        disabledColor: kFaint,
                        tooltip: 'Vrátit poslední kartu',
                        onPressed: c.canUndo ? c.undo : null,
                        icon: const Icon(Icons.undo_rounded),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                RoundedProgressBar(
                  value: c.phaseProgress,
                  color: reviewing ? kToneGreen.solidA : kLearningColor,
                ),
              ],
            ),
          ),
          // Karta je vždy uprostřed této oblasti; tlačítka (jen při představení
          // nových slov) jsou přes ni položená dole a pozici karty neovlivňují.
          Expanded(
            child: LayoutBuilder(
              builder: (context, box) {
                // Karta se smí protáhnout jen tak, aby se vešla (a nepřekrývala
                // tlačítka při představení nových slov).
                final maxCard = math.max(
                  kCardSize,
                  box.maxHeight -
                      (showButtons
                          ? kIntroButtonHeight + kIntroButtonsBottom + 24
                          : 24),
                );
                return Stack(
                  children: [
                    Center(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          if (nxt != null)
                            FlashCard(
                              key: ValueKey('bottom-${c.serial}-$nxt'),
                              course: c.course,
                              index: nxt,
                              number: c.numberOf(nxt),
                              info: c.infoOf(nxt),
                              showBack: false,
                              nativeFront: c.nativeFrontFor(nxt),
                              interactive: false,
                              maxHeight: maxCard,
                              onFlip: () {},
                              onAnswered: (_) {},
                            )
                          else
                            const SizedBox(width: 300, height: 308),
                          if (top != null && c.isIntro)
                            IntroCard(
                              key: ValueKey('top-${c.serial}'),
                              course: c.course,
                              index: top,
                              number: c.numberOf(top),
                              info: c.infoOf(top),
                              maxHeight: maxCard,
                              haptics: c.settings.haptics,
                              dragOffset: _drag,
                              // doprava = už umím, doleva = naučit (jako tlačítka)
                              onSwiped:
                                  (known) =>
                                      known ? c.skipIntro() : c.ackIntro(),
                            )
                          else if (top != null)
                            FlashCard(
                              key: ValueKey('top-${c.serial}'),
                              course: c.course,
                              index: top,
                              number: c.numberOf(top),
                              info: c.infoOf(top),
                              showBack: c.showBack,
                              nativeFront: c.nativeFrontFor(top),
                              maxHeight: maxCard,
                              haptics: c.settings.haptics,
                              onFlip: c.flip,
                              onAnswered: c.answer,
                              dragOffset: _drag,
                            ),
                        ],
                      ),
                    ),
                    Positioned.fill(
                      child: SwipeHint(
                        drag: _drag,
                        left:
                            showButtons
                                ? SwipeSide(
                                  text: 'Naučit se',
                                  icon: Icons.menu_book_rounded,
                                  tone: kToneAmber,
                                )
                                : SwipeSide(
                                  text: 'Ještě zopakovat',
                                  icon: Icons.replay_rounded,
                                  tone: kToneAmber,
                                ),
                        right: SwipeSide(
                          text: c.isIntro ? 'Už umím' : 'Umím!',
                          icon: Icons.check_rounded,
                          tone: kToneGreen,
                        ),
                      ),
                    ),
                    if (showButtons)
                      Positioned(
                        left: 20,
                        right: 20,
                        bottom: kIntroButtonsBottom,
                        height: kIntroButtonHeight,
                        child: Row(
                          children: [
                            Expanded(
                              child: ToneButton(
                                label: 'Naučit',
                                icon: Icons.menu_book_rounded,
                                tone: kToneAmber,
                                height: kIntroButtonHeight,
                                fontSize: 15,
                                onPressed:
                                    firstTry
                                        ? () => c.answer(false)
                                        : c.ackIntro,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ToneButton(
                                label: firstTry ? 'Umím' : 'Už umím',
                                icon: Icons.check_rounded,
                                tone: kToneGreen,
                                height: kIntroButtonHeight,
                                fontSize: 15,
                                onPressed:
                                    firstTry
                                        ? () => c.answer(true)
                                        : c.skipIntro,
                              ),
                            ),
                            if (top != null && c.canExclude(top)) ...[
                              const SizedBox(width: 12),
                              _ExcludeButton(
                                height: kIntroButtonHeight,
                                onPressed: () => _exclude(top),
                              ),
                            ],
                          ],
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


/// Malé neutrální tlačítko "Neučit" vedle Naučit / Umím.
class _ExcludeButton extends StatelessWidget {
  final double height;
  final VoidCallback onPressed;
  const _ExcludeButton({required this.height, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: 'Neučit: slovo se už nezobrazí',
      child: Material(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onPressed,
          child: Container(
            width: 74,
            height: height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kFaint),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.visibility_off_outlined, size: 18, color: kMuted),
                Text(
                  'Neučit',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: kMuted,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
